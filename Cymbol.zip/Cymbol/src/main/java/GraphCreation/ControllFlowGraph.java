package GraphCreation;

import Cymbol.output.CymbolLexer;
import guru.nidi.graphviz.attribute.*;
import guru.nidi.graphviz.engine.Format;
import guru.nidi.graphviz.engine.Graphviz;
import guru.nidi.graphviz.model.Factory.*;
import guru.nidi.graphviz.model.Graph;

import guru.nidi.graphviz.model.Node;
import org.antlr.runtime.tree.DOTTreeGenerator;
import org.stringtemplate.v4.ST;
import org.stringtemplate.v4.STGroup;
import org.stringtemplate.v4.STGroupDir;
import org.stringtemplate.v4.STGroupFile;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static guru.nidi.graphviz.model.Factory.*;



public class ControllFlowGraph {

    protected STGroup group;
    protected List<Node> nodes;
    protected List<Link> links;


    ControllFlowGraph() throws IOException {
        //FileReader fr = new FileReader("Cymbol.stg");
        group = new STGroupFile("/home/tj/Documents/FH/VSys/Cymbol/src/main/java/GraphCreation/Cymbol.stg");
        nodes = new ArrayList<Node>();
        links = new ArrayList<Link>();

    }



    public static class Link {
        String from;
        String to;
        String label;

        public Link(String from, String to, String label) {
            this.from = from;
            this.to = to;
            this.label = label;
        }
    }



    public static class Node {
        String name;
        String label;

        public Node(String name, String label) {
            this.name = name;
            this.label = label;
        }

    }

    public void addLink(String from, String to, String label) {

        boolean duplicate = false;
        Link tmp = new Link(from, to, label);
        for(Link x : links)
        {
            if(x.from.equals(tmp.from) && x.to.equals(tmp.to)) {
                duplicate = true;
                break;
            }
        }

        if(!duplicate)
            links.add(tmp);
    }

    public void addNode(String name, String label)
    {
        nodes.add(new Node(name, label));
    }

    public String toString() {
        ST fileST = group.getInstanceOf("file");
        fileST.add("gname", "testgraph");
        for (Link x : links) {
            ST edgeST = group.getInstanceOf("edge");
            edgeST.add("from", x.from);
            edgeST.add("to", x.to);
            edgeST.add("label", x.label);
            //System.out.println(edgeST.render());
            fileST.add("edges", edgeST);
        }

        for (Node x : nodes) {
            ST nodeST = group.getInstanceOf("node");
            nodeST.add("name", x.name);
            nodeST.add("label", x.label);
            fileST.add("nodes", nodeST);
        }

        try {
            Graphviz.fromString(fileST.render()).width(900).render(Format.PNG).toFile(new File("/home/tj/Documents/FH/VSys/Cymbol/src/main/java/GraphCreation/output.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fileST.render();
    }


    public static void main(String[] args) {

       // group = new STGroupFile("/home/tj/Documents/FH/VSys/Cymbol/src/main/java/GraphCreation/Cymbol.stg");

    }


    private void initST()
    { }

    /*
    private void makeExample() throws IOException {
        Node
                main = node("main").with(Label.html("<b>main</b><br/>start"), Color.rgb("1020d0").font()),
                init = node(Label.markdown("**_init_**")),
                execute = node("execute"),
                compare = node("compare").with(Shape.RECTANGLE, Style.FILLED, Color.hsv(.7, .3, 1.0)),
                mkString = node("mkString").with(Label.of("make a\nstring")),
                printf = node("printf");

        Graph g = graph("example2").directed().with(
                main.link(
                        to(node("parse").link(execute)).with(LinkAttr.weight(8)),
                        to(init).with(Style.DOTTED),
                        node("cleanup"),
                        to(printf).with(Style.BOLD, Label.of("100 times"), Color.RED)),
                execute.link(
                        graph().with(mkString, printf),
                        to(compare).with(Color.RED)),
                init.link(mkString));

        Graphviz.fromGraph(g).width(900).render(Format.PNG).toFile(new File("example/ex2.png"));
    }
    */
}
