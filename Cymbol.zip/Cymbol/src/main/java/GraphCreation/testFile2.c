int manhattan(int a, int b) {
if (a < 0)
a = -a;
if (b < 0)
b = -b;
return a+b;
}
