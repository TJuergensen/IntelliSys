package GraphCreation;

import Cymbol.output.CymbolBaseListener;
import Cymbol.output.CymbolParser;
import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ErrorNode;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeProperty;
import org.antlr.v4.runtime.tree.TerminalNode;
import org.stringtemplate.v4.ST;
import org.stringtemplate.v4.STGroup;
import org.stringtemplate.v4.STGroupFile;

public class Listener extends CymbolBaseListener {

    private ControllFlowGraph CFG;
    private STGroup group = new STGroupFile("/home/tj/Documents/FH/VSys/Cymbol/src/main/java/GraphCreation/Cymbol.stg");
    private static boolean ifCondition = false;
    ParseTreeProperty<Integer> values = new ParseTreeProperty<Integer>();

    private static int nodeNumber = 0;
    private static boolean inBlock = false;

    public void setValue(ParseTree node, Integer val)
    {
        values.put(node, val);
    }

    public int getValue(ParseTree node)
    {
        return values.get(node);
    }

    public Listener(ControllFlowGraph g)
    {
        this.CFG = g;
    }

    @Override
    public void enterFile(CymbolParser.FileContext ctx) {
        super.enterFile(ctx);
        addNode("node", "start");

    }

    @Override
    public void exitFile(CymbolParser.FileContext ctx) {
        super.exitFile(ctx);
        CFG.addLink(""+(nodeNumber-1), ""+nodeNumber, "");
        addNode("node", "end");

        //CFG.nodes.add(0, new ControllFlowGraph.Node("start", "start"));
        //CFG.addLink(""+0, ""+1, "");
    }

    @Override
    public void enterBLOCK(CymbolParser.BLOCKContext ctx) {
        super.enterBLOCK(ctx);
        inBlock = true;
    }

    @Override
    public void exitBLOCK(CymbolParser.BLOCKContext ctx) {
        super.exitBLOCK(ctx);
        inBlock = false;
    }

    @Override
    public void enterVARDEC(CymbolParser.VARDECContext ctx) {
        super.enterVARDEC(ctx);

        if(!ifCondition) {
            if(!inBlock)
            {
                CFG.addLink("" + (nodeNumber - 1), "" + nodeNumber, "");
            }
            String type = ctx.varDecl().type().getText();
            String id = ctx.varDecl().ID().getText();

            if (ctx.varDecl().expr() != null) {
                String expr = ctx.varDecl().expr().getText();
                if(inBlock)
                    addNode("node", type + " " + id + " " + expr);
                if(!inBlock)
                    CFG.nodes.get(nodeNumber-1).label+="\n"+type + " " + id + " " + expr;
            } else {
                if(inBlock)
                    addNode("node", type + " " + id);
                if(!inBlock)
                    CFG.nodes.get(nodeNumber-1).label+="\n"+type + " " + id;
            }
        }


    }



    @Override
    public void enterIF(CymbolParser.IFContext ctx) {
        super.enterIF(ctx);
        ifCondition = true;

        CFG.addLink(""+(nodeNumber-1), ""+nodeNumber,""); //Link to this node
        int startIf = nodeNumber;
        addNode("node", "if");

        String labelLeft ="";
        for(CymbolParser.StatContext s: ctx.block(0).stat()){
            labelLeft += s.getText()+"\n";
        }

        CFG.addLink(""+startIf,""+nodeNumber,ctx.expr().getText()); //connect IF with this node
        CFG.addLink(""+nodeNumber,""+(nodeNumber+2),"");
        addNode("node", labelLeft);

        if(ctx.block(1) != null)
        {
            String labelRight ="";
            for(CymbolParser.StatContext s: ctx.block(1).stat()){
                labelRight += s.getText()+"\n";
            }
            CFG.addLink(""+startIf,""+nodeNumber,"else"); //connect IF with this node (else)
            addNode("node", labelRight);
        }



    }
    @Override
    public void exitIF(CymbolParser.IFContext ctx) {
        super.exitIF(ctx);
        ifCondition=false;
    }

    @Override
    public void enterIFSINGLE(CymbolParser.IFSINGLEContext ctx) {
        super.enterIFSINGLE(ctx);
        ifCondition = true;
        int startIF = nodeNumber;
        CFG.addLink(""+(nodeNumber-1),""+nodeNumber , ""); //connect previous Node with this IF
        addNode("node", "if");

        String childLabel = ctx.stat().getText();
        CFG.addLink(""+startIF,""+nodeNumber , ctx.expr().getText()); //connect IF with this
        CFG.addLink(""+nodeNumber,""+(nodeNumber+1) , ""); //connect IF with this
        addNode("node", childLabel);
        CFG.addLink(""+startIF,""+nodeNumber , "else");



    }
    public void exitIFSINGLE(CymbolParser.IFSINGLEContext ctx) {
        super.exitIFSINGLE(ctx);
        ifCondition = false;
    }

    @Override
    public void enterFOR(CymbolParser.FORContext ctx) {
        super.enterFOR(ctx);

        int start = nodeNumber;
        CFG.addLink(""+(nodeNumber-1), ""+start, "");//connect previous Node with this node
        addNode("node", "for"); //add this node



         String id2 ="";
        if(ctx.INT().size() == 2){
            id2 = ctx.INT(1).getText();
        } else {
            id2 = ctx.ID(2).getText();
        }
        String label = ctx.ID(0) + ctx.BOOL().getText()+id2;
        int blockSize = ctx.block().stat().size();

        for(int i=0; i< blockSize; i++)
        {
            //CFG.addLink(""+(nodeNumber-1), ""+start, "");//connect previous Node with this node
            String nodeLabel = ctx.block().stat(i).getText();
            CFG.addNode(""+nodeNumber, nodeLabel);

        }

        CFG.addLink(""+(nodeNumber+blockSize), ""+start, ""); //connect last statment in for to head
        CFG.addLink(""+start, ""+(nodeNumber+blockSize+1),"else");


/*
        CFG.addLink(""+blockEnd,""+start,"");
        CFG.addLink(""+start,""+(blockEnd+1),"else");
        CFG.addLink(""+start,""+(start+1),label);
*/

    }


    @Override
    public void enterRETURN(CymbolParser.RETURNContext ctx) {
        super.enterRETURN(ctx);

        CFG.addLink(""+(nodeNumber-1), ""+nodeNumber, "");//connect previous Node with this node
        addNode("node", ctx.getText()); //add this node

    }


    @Override
    public void enterASSIGN(CymbolParser.ASSIGNContext ctx) {
        super.enterASSIGN(ctx);
    }


    @Override
    public void enterNOIDEA(CymbolParser.NOIDEAContext ctx) {
        super.enterNOIDEA(ctx);
    }



    @Override
    public void enterINCREMENT(CymbolParser.INCREMENTContext ctx) {
        super.enterINCREMENT(ctx);

    }

    @Override
    public void enterARRAY(CymbolParser.ARRAYContext ctx) {
        super.enterARRAY(ctx);
    }


    @Override
    public void enterBOOL(CymbolParser.BOOLContext ctx) {
        super.enterBOOL(ctx);
    }


    @Override
    public void enterADDSUB(CymbolParser.ADDSUBContext ctx) {
        super.enterADDSUB(ctx);
    }


    @Override
    public void enterUNARYMINUS(CymbolParser.UNARYMINUSContext ctx) {
        super.enterUNARYMINUS(ctx);
    }

    @Override
    public void exitUNARYMINUS(CymbolParser.UNARYMINUSContext ctx) {
        super.exitUNARYMINUS(ctx);
//        int val = getValue(ctx.expr());
//        val = val*(-1);
//        setValue(ctx,val);
    }


    @Override
    public void enterMULDIV(CymbolParser.MULDIVContext ctx) {
        super.enterMULDIV(ctx);
    }

    @Override
    public void exitMULDIV(CymbolParser.MULDIVContext ctx) {
        super.exitMULDIV(ctx);
        int left = getValue(ctx.expr(0));
        int right = getValue(ctx.expr(1));

        if(ctx.op.getText().equals("*"))
            setValue(ctx, left*right);

        if(ctx.op.getText().equals("/"))
            setValue(ctx,left/right);
    }

    @Override
    public void enterBOOLNOT(CymbolParser.BOOLNOTContext ctx) {
        super.enterBOOLNOT(ctx);

    }

    @Override
    public void exitBOOLNOT(CymbolParser.BOOLNOTContext ctx) {
        super.exitBOOLNOT(ctx);
        int val = getValue(ctx);
        val *= -1;
        setValue(ctx, val);
    }

    @Override
    public void enterINT(CymbolParser.INTContext ctx) {
        super.enterINT(ctx);
    }

    @Override
    public void exitINT(CymbolParser.INTContext ctx) {
        super.exitINT(ctx);
        String intText = ctx.INT().getText();
        setValue(ctx, Integer.valueOf(intText));
    }

    @Override
    public void enterFUNCCALL(CymbolParser.FUNCCALLContext ctx) {
        super.enterFUNCCALL(ctx);
        String label = ctx.ID().getText() + "(";


        if(!nodeDuplicate(nodeNumber-1, label)) {
        //if(!ifCondition) {
            CFG.addLink("" + (nodeNumber - 1), "" + nodeNumber, "");

            if (ctx.exprList() != null)
                label += ctx.exprList().toString();
            label += ");";
            addNode("node", label);
        }

    }



    private void addNode(String type, String label)
    {
        //ST tmp = group.getInstanceOf(type);
        //tmp.add("name", nodeNumber++);
        //tmp.add("label", label);
        CFG.addNode(""+nodeNumber++, label);
    }

    private boolean nodeDuplicate(int nodeNumber, String label)
    {
        boolean ret = false;

        ControllFlowGraph.Node dummy= CFG.nodes.get(nodeNumber-1);
        if(dummy.label.contains(label))
            ret=true;

        return ret;
    }

}
