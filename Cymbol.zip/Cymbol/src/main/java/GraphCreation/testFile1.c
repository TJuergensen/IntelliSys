void a(int x){
    int y;
    if(x == 3) {
        b();
        c();
    } else {y=4;}
    for(i=0; i<=3; i=i+1) {
    if(i==2) e();
    d();
    }
}
