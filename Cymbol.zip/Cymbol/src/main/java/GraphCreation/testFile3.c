void foobar(int[] a) {
for (int i=0; i < 512; i=i+1) {
if (a[i])
foo();
else
bar();
}
}
