package GraphCreation;

import Cymbol.output.CymbolLexer;
import Cymbol.output.CymbolParser;
import org.antlr.v4.runtime.ANTLRFileStream;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

import java.io.IOException;
import java.io.PrintWriter;

public class main {

    public static void main(String[] args) throws IOException {

        ControllFlowGraph g = new ControllFlowGraph();
        String path ="/home/tj/Documents/FH/VSys/Cymbol/src/main/java/GraphCreation/testFile2.c";
        CharStream input =  new ANTLRFileStream(path);
        CymbolLexer lex = new CymbolLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lex);
        CymbolParser parser = new CymbolParser(tokens);


        ParseTree tree = parser.file();
        ParseTreeWalker walker = new ParseTreeWalker();

        Listener listener = new Listener(g);
        walker.walk(listener, tree);

        //PrintWriter DOTWriter = new PrintWriter("");
        System.out.println(g.toString());



    }

}
